<template>
  <div style="text-align: center;margin: auto;">
    Not Found Resource!
  </div>
</template>

<script>
export default {
  name: 'notFound'
}
</script>

<style lang="scss" scoped>
</style>
