<template>
  <div>
    {{ name }}
  </div>
</template>

<script>
export default {
  name: 'agenda',
  data() {
    return {
      name: 'Agenda'
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
