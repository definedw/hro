<template>
  <div>
    {{ name }}
  </div>
</template>

<script>
export default {
  name: 'overAgenda',
  data() {
    return {
      name: 'OverAgenda'
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
