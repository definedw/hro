import storage from './storage'

export {
  storage
}
